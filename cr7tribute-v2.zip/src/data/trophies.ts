import { Trophy } from "@/types/trophy";

export const TROPHIES_DATA: Trophy[] = [
  // CLUB TROPHIES
  { id: "ucl", name: "UEFA Champions League", count: 5, years: [2008, 2014, 2016, 2017, 2018], icon: "🏆", tier: "gold", category: "club", description: "The pinnacle of European club football. Five titles across two clubs, including a historic three-peat with Real Madrid.", firstWon: 2008, mostRecent: 2018 },
  { id: "pl", name: "Premier League", count: 3, years: [2007, 2008, 2009], icon: "🥇", tier: "gold", category: "club", description: "Three consecutive Premier League titles with Manchester United during his first golden era.", firstWon: 2007, mostRecent: 2009 },
  { id: "laliga", name: "La Liga", count: 2, years: [2012, 2017], icon: "🥇", tier: "gold", category: "club", description: "Two Spanish league titles in nine seasons with Real Madrid.", firstWon: 2012, mostRecent: 2017 },
  { id: "seriea", name: "Serie A", count: 2, years: [2019, 2020], icon: "🥇", tier: "gold", category: "club", description: "Back-to-back Italian league titles in his first two seasons with Juventus.", firstWon: 2019, mostRecent: 2020 },
  { id: "facup", name: "FA Cup", count: 1, years: [2004], icon: "🏆", tier: "silver", category: "club", description: "Won with Manchester United in his second season in England.", firstWon: 2004, mostRecent: 2004 },
  { id: "carabao", name: "League Cup", count: 2, years: [2006, 2009], icon: "🏆", tier: "silver", category: "club", description: "Two League Cup trophies with Manchester United.", firstWon: 2006, mostRecent: 2009 },
  { id: "cwc", name: "FIFA Club World Cup", count: 4, years: [2008, 2014, 2016, 2017], icon: "🌍", tier: "gold", category: "club", description: "Four Club World Cups across Manchester United and Real Madrid.", firstWon: 2008, mostRecent: 2017 },
  { id: "supercup", name: "UEFA Super Cup", count: 3, years: [2014, 2016, 2017], icon: "🏆", tier: "gold", category: "club", description: "Three UEFA Super Cups with Real Madrid.", firstWon: 2014, mostRecent: 2017 },
  { id: "saudileague", name: "Saudi Pro League", count: 0, years: [], icon: "🥇", tier: "bronze", category: "club", description: "Currently competing with Al Nassr in the Saudi Pro League.", firstWon: 0, mostRecent: 0 },
  // INTERNATIONAL
  { id: "euro2016", name: "UEFA Euro 2016", count: 1, years: [2016], icon: "🇵🇹", tier: "gold", category: "international", description: "Portugal's first major international trophy, captained by Ronaldo.", firstWon: 2016, mostRecent: 2016 },
  { id: "nationsleague", name: "UEFA Nations League", count: 1, years: [2019], icon: "🏆", tier: "gold", category: "international", description: "First-ever Nations League title, won on home soil in Portugal.", firstWon: 2019, mostRecent: 2019 },
  // INDIVIDUAL
  { id: "ballondor", name: "Ballon d'Or", count: 5, years: [2008, 2013, 2014, 2016, 2017], icon: "🌟", tier: "gold", category: "individual", description: "Five Ballon d'Or awards — second-most in history.", firstWon: 2008, mostRecent: 2017 },
  { id: "goldenshoe", name: "European Golden Shoe", count: 4, years: [2008, 2011, 2014, 2015], icon: "👟", tier: "gold", category: "individual", description: "Four European Golden Shoes for top scorer in European leagues.", firstWon: 2008, mostRecent: 2015 },
  { id: "fifabest", name: "FIFA Best Player", count: 3, years: [2008, 2016, 2017], icon: "🥇", tier: "gold", category: "individual", description: "Three FIFA Best Player awards.", firstWon: 2008, mostRecent: 2017 },
  { id: "puskas", name: "Puskás Award", count: 1, years: [2009], icon: "🎯", tier: "gold", category: "individual", description: "Best goal of the year for his 40-yard missile against Porto.", firstWon: 2009, mostRecent: 2009 },
  { id: "goldenboot", name: "World Cup Golden Boot", count: 1, years: [2018], icon: "👟", tier: "silver", category: "individual", description: "Top scorer at the 2018 World Cup.", firstWon: 2008, mostRecent: 2018 },
  // RECORDS
  { id: "goat_ucl", name: "UCL All-Time Top Scorer", count: 140, years: [], icon: "⚽", tier: "gold", category: "records", description: "All-time leading goalscorer in the UEFA Champions League.", firstWon: 0, mostRecent: 2024 },
  { id: "goat_int", name: "International Top Scorer", count: 133, years: [], icon: "🌍", tier: "gold", category: "records", description: "All-time leading goalscorer in men's international football.", firstWon: 0, mostRecent: 2024 },
  { id: "goat_caps", name: "Most International Caps", count: 216, years: [], icon: "🎽", tier: "gold", category: "records", description: "Most capped player in men's international football history.", firstWon: 0, mostRecent: 2024 },
  { id: "goat_hattricks", name: "Most International Hat-Tricks", count: 10, years: [], icon: "🎩", tier: "gold", category: "records", description: "Most hat-tricks in men's international football.", firstWon: 0, mostRecent: 2024 },
  { id: "goat_goals", name: "900+ Career Goals", count: 907, years: [], icon: "🔥", tier: "gold", category: "records", description: "First player in history to score 900+ official career goals.", firstWon: 0, mostRecent: 2024 },
];

export const TROPHY_CATEGORIES: { id: "all" | "club" | "international" | "individual" | "records"; label: string }[] = [
  { id: "all", label: "All Trophies" },
  { id: "club", label: "Club" },
  { id: "international", label: "International" },
  { id: "individual", label: "Individual" },
  { id: "records", label: "Records" },
];
