export interface Goal {
  id: string;
  title: string;
  opponent: string;
  competition: string;
  year: number;
  minute: number;
  videoId: string;
  thumbnail: string;
  description: string;
}

export const GOALS_DATA: Goal[] = [
  { id: "turin-bicycle", title: "The Turin Bicycle Kick", opponent: "Juventus", competition: "UCL Quarter-Final", year: 2018, minute: 64, videoId: "vJ3B8sFEZvw", thumbnail: "https://img.youtube.com/vi/vJ3B8sFEZvw/maxresdefault.jpg", description: "A 2.38-meter overhead kick that silenced the Juventus crowd and earned a standing ovation." },
  { id: "portsmouth", title: "The Portsmouth Knuckleball", opponent: "Portsmouth", competition: "Premier League", year: 2008, minute: 12, videoId: "RZ0ZQ_M3GfY", thumbnail: "https://img.youtube.com/vi/RZ0ZQ_M3GfY/maxresdefault.jpg", description: "A 40-yard free kick with zero spin that dipped at the last moment." },
  { id: "sampdoria", title: "The 2.56m Leap", opponent: "Sampdoria", competition: "Serie A", year: 2019, minute: 45, videoId: "LpQp6g_1YgU", thumbnail: "https://img.youtube.com/vi/LpQp6g_1YgU/maxresdefault.jpg", description: "A gravity-defying header at 2.56 meters — higher than the crossbar." },
  { id: "spain-hattrick", title: "World Cup Hat-Trick vs Spain", opponent: "Spain", competition: "World Cup 2018", year: 2018, minute: 88, videoId: "yJcBzXvGZqM", thumbnail: "https://img.youtube.com/vi/yJcBzXvGZqM/maxresdefault.jpg", description: "A last-minute free kick to complete a historic hat-trick against Spain." },
  { id: "porto-missile", title: "The 40-Yard Missile", opponent: "FC Porto", competition: "UCL Quarter-Final", year: 2009, minute: 6, videoId: "0aCjN0fE5eE", thumbnail: "https://img.youtube.com/vi/0aCjN0fE5eE/maxresdefault.jpg", description: "A 40-yard rocket that won the inaugural Puskás Award." },
  { id: "atletico-comeback", title: "The Atletico Comeback", opponent: "Atletico Madrid", competition: "UCL Round of 16", year: 2019, minute: 86, videoId: "gY4-9XtKXY", thumbnail: "https://img.youtube.com/vi/gY4-9XtKXY/maxresdefault.jpg", description: "A hat-trick to complete the impossible comeback against Atletico Madrid." },
  { id: "arsenal-fk", title: "The Arsenal Free Kick", opponent: "Arsenal", competition: "UCL Semi-Final", year: 2009, minute: 40, videoId: "RZ0ZQ_M3GfY", thumbnail: "https://img.youtube.com/vi/RZ0ZQ_M3GfY/maxresdefault.jpg", description: "A long-range free kick from 40 yards out that stunned the Emirates." },
  { id: "campnou-calma", title: "The Calma at Camp Nou", opponent: "Barcelona", competition: "La Liga", year: 2012, minute: 73, videoId: "yJcBzXvGZqM", thumbnail: "https://img.youtube.com/vi/yJcBzXvGZqM/maxresdefault.jpg", description: "The iconic winner at Camp Nou, followed by the legendary 'Calma' celebration." },
];
